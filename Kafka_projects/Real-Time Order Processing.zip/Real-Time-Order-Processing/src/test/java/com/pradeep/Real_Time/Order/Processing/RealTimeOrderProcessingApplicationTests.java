package com.pradeep.Real_Time.Order.Processing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealTimeOrderProcessingApplicationTests {

	@Test
	void contextLoads() {
	}

}

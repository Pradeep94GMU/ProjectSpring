package com.pradeep.ExternalAPi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExternalAPiApplicationTests {

	@Test
	void contextLoads() {
	}

}
